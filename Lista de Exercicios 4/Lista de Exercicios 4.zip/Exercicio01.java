public class Exercicio01 {
    public static void main(String[] args) {
        int [] vetor = {1,2,3,4,6,5,69,78};

        for (int i = 0; i < vetor.length; i++)
        {
            System.out.println(vetor[i]);
        }
    }
}
