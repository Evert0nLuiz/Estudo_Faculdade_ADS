public class Exercicio15 {
    public static void main(String[] args) {
        int [] vetor = {1,2,3,4,6};
        int i = vetor.length-1;
        while(i >= 0)
        
        {
            System.out.println(vetor[i]);
            i--;
        }
    }
    
}
